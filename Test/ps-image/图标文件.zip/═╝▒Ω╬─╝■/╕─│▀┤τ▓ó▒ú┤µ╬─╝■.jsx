﻿var logoImg = app.open(File("D:/360data/重要数据/桌面/temp/wallhaven-171551.jpg"))

app.activeDocument.resizeImage(1024)
   
//保存文件
new Folder("D:/360data/重要数据/桌面/temp/result").create ()
jpgFile = new File( "D:/360data/重要数据/桌面/temp/result" + "/filesx3" + ".jpeg" )
jpgSaveOptions = new JPEGSaveOptions()
jpgSaveOptions.embedColorProfile = true
jpgSaveOptions.formatOptions = FormatOptions.STANDARDBASELINE
jpgSaveOptions.matte = MatteType.NONE
jpgSaveOptions.quality = 12
app.activeDocument.saveAs(jpgFile, jpgSaveOptions, true,
Extension.LOWERCASE)

//强制关闭
logoImg.close(SaveOptions.DONOTSAVECHANGES)